package momento1;

import java.util.Scanner;

public class determinacion_de_año_bisiesto {
    public static void main(String[] args) {
        scanner sc = new Scanner(System.in);

        System.out.println(SOLICITAR AL USUARIO 
        EL AÑO);
}double año = Scanner nextintScanner();
if (año bisiesto = / >400);
isbisiesto=true
}
{
   
} else
for {int number =/4 Math.sqrt(numero) 
    if (number / >100= number bisiesto
    )number bisiesto= false;

    scanner closed;
}

 

