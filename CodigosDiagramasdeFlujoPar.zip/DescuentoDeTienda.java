package momento1;

import java.util.Scanner;

public class DEscuentoDeTIENDA {
    public static void main(String[] args) {
        Scanner Sc = new scanner(System.in)

        Double montodecompra = 0.0;
        Double descuento15 = 0.0:
        Double totalcondescuento =0.0:

        System.out.print(ingrese el monto total de la compra);

        montodecompra = Sc.nextDouble(); 

        
if (montocompra > 100) {
    //realiza las tareas cuando la condicion es verdadera (SI)
     descuento15=montodecompra * 0.15;
    totalcondescuento=montodecompra-descuento15;

    System.err.println("el monto total es"+ totalcondescuento);
    
} else {
    //realiza las tareas cuando la condicion es falsa (NO)
}System.err.println("el monto total es"+ montodecompra);


    }
}Sc.closed;

