package momento1;

import java.util.Scanner;

public class numero_par_o_impar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double number = "es par o impar";
        System.out.println("number par");
        if (numero <= 1) {
            es_par = false;
        } else {
            for (int i = 2; );
                


    int number = sc.nextInt();

}
sc. closed;
