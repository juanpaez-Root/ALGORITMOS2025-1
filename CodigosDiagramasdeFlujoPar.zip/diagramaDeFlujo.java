package momento1;

import java.util.Scanner;

public class diagramaDeFlujo {
    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);    
    
        double number1 = 0.0;
        double number2 =0.0;

        System.out.print("number1 es mayor a number2") ;
        int number = sc.nextInt();

        System.out.println(number1+"+5="+number2);

    
if (si el segundo es mayor) {
   //Realiza las tareas cuando la condicion es verdadera (SI)
   System.err.println("si el segundo es mayor");
} else {
   //Realizalas tareas cuando la condicion es falsa (NO)
   System.err.println("si son iguales");
   
   


   sc.closed;
}
